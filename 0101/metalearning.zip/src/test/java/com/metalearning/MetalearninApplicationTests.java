package com.metalearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetalearninApplicationTests {

	@Test
	void contextLoads() {
	}

}
