//package com.metalearnin.utility;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//// ErrorController는 에러 발생 시 커스텀 페이지를 제공하기 위한 컨트롤러입니다.
//@Controller
//public class ErrorController implements org.springframework.boot.web.servlet.error.ErrorController {
//
//    // 에러가 발생하면 "/error" 경로로 매핑됩니다.
//    @RequestMapping("/error")
//    public String handleError() {
//        // 에러 발생 시 커스텀 에러 페이지를 반환
//        return "/utility/error";  // /templates/Utility/Error.html을 렌더링
//    }
//}
